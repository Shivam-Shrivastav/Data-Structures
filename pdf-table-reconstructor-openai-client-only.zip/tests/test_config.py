import os
import pytest
from config import Config

def test_invalid_provider(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "bad-provider")
    monkeypatch.setenv("ENABLE_LLM", "false")
    with pytest.raises(ValueError):
        Config.from_env()
