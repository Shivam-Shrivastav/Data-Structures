"""
End-to-end PDF table extraction with LlamaParse.

Input:
    A PDF file or a folder containing PDFs.

Output:
    output/
      <pdf_stem>/
        tables/
          table_0001_page_0001.html
          table_0002_page_0001.html
          table_0003_pages_0002-0003.html
        metadata/
          tables_manifest.json
          parse_summary.json

Notes:
- Uses LlamaParse's hosted parsing service and therefore requires LLAMA_CLOUD_API_KEY.
- This script does not make a separate Microsoft Foundry/OpenAI API call.
- When merge_continued_tables is enabled, LlamaParse may return a multi-page table
  as one table item on its first page and provide merged_from_pages metadata.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from llama_cloud import LlamaCloud

LOG = logging.getLogger("llamaparse_table_extractor")


def safe_name(value: str, max_len: int = 100) -> str:
    """Create a filesystem-safe name."""
    value = re.sub(r"[^\w.-]+", "_", value.strip(), flags=re.UNICODE)
    value = re.sub(r"_+", "_", value).strip("._")
    return (value or "document")[:max_len]


def get_value(obj: Any, key: str, default: Any = None) -> Any:
    """Read a field from either an SDK model or a dictionary."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def json_safe(value: Any) -> Any:
    """Convert SDK models and nested values into JSON-compatible structures."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if hasattr(value, "model_dump"):
        try:
            return json_safe(value.model_dump(mode="json", exclude_none=True))
        except Exception:
            pass
    if hasattr(value, "dict"):
        try:
            return json_safe(value.dict(exclude_none=True))
        except Exception:
            pass
    if hasattr(value, "__dict__"):
        try:
            return json_safe(vars(value))
        except Exception:
            pass
    return str(value)


def wrap_table_html(table_html: str, title: str, source_pdf: str, pages: list[int]) -> str:
    """Wrap a returned table fragment in a standalone, readable HTML document."""
    fragment = (table_html or "").strip()
    if not fragment:
        fragment = "<table><tbody><tr><td>No HTML table was returned by LlamaParse.</td></tr></tbody></table>"

    # LlamaParse's table.html is normally a table fragment. Avoid nesting a full
    # HTML document inside another document.
    if re.search(r"<html\b", fragment, flags=re.IGNORECASE):
        return fragment

    page_text = ", ".join(map(str, pages)) if pages else "unknown"
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title}</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; color: #222; }}
    .metadata {{ color: #555; font-size: 13px; margin-bottom: 16px; }}
    table {{ border-collapse: collapse; width: 100%; }}
    th, td {{ border: 1px solid #bbb; padding: 6px 8px; vertical-align: top; }}
    th {{ background: #f1f3f5; font-weight: 600; }}
    tr {{ page-break-inside: avoid; }}
  </style>
</head>
<body>
  <h2>{title}</h2>
  <div class="metadata">Source PDF: {source_pdf} · Page(s): {page_text}</div>
  {fragment}
</body>
</html>
"""


def collect_tables(result: Any) -> list[dict[str, Any]]:
    """Collect typed table items from LlamaParse's page items."""
    items_root = get_value(result, "items")
    pages = get_value(items_root, "pages", []) or []
    collected: list[dict[str, Any]] = []

    for page in pages:
        if not get_value(page, "success", True):
            LOG.warning("Skipping failed page %s", get_value(page, "page_number", "?"))
            continue

        page_number = get_value(page, "page_number")
        for item in get_value(page, "items", []) or []:
            item_type = get_value(item, "type", "")
            if str(item_type).lower() != "table":
                continue

            merged_from_pages = get_value(item, "merged_from_pages") or []
            if isinstance(merged_from_pages, tuple):
                merged_from_pages = list(merged_from_pages)

            page_numbers = []
            if page_number is not None:
                page_numbers.append(int(page_number))
            for p in merged_from_pages:
                try:
                    p = int(p)
                    if p not in page_numbers:
                        page_numbers.append(p)
                except (TypeError, ValueError):
                    pass
            page_numbers.sort()

            collected.append({
                "page_number": int(page_number) if page_number is not None else None,
                "page_numbers": page_numbers,
                "merged_from_pages": json_safe(merged_from_pages),
                "merged_into_page": json_safe(get_value(item, "merged_into_page")),
                "html": get_value(item, "html") or "",
                "md": get_value(item, "md") or "",
                "csv": get_value(item, "csv") or "",
                "rows": json_safe(get_value(item, "rows") or []),
                "bbox": json_safe(get_value(item, "bbox")),
                "parse_concerns": json_safe(get_value(item, "parse_concerns")),
                "raw_item": json_safe(item),
            })

    return collected


def process_pdf(
    client: LlamaCloud,
    pdf_path: Path,
    output_root: Path,
    tier: str,
    merge_continued_tables: bool,
    version: str,
    retry_count: int,
) -> dict[str, Any]:
    pdf_name = safe_name(pdf_path.stem)
    document_dir = output_root / pdf_name
    tables_dir = document_dir / "tables"
    metadata_dir = document_dir / "metadata"
    tables_dir.mkdir(parents=True, exist_ok=True)
    metadata_dir.mkdir(parents=True, exist_ok=True)

    LOG.info("Uploading %s", pdf_path)
    uploaded_file = client.files.create(file=str(pdf_path), purpose="parse")

    LOG.info("Parsing %s (tier=%s)", pdf_path.name, tier)
    last_error = None
    result = None

    for attempt in range(retry_count + 1):
        try:
            result = client.parsing.parse(
                file_id=uploaded_file.id,
                tier=tier,
                version=version,
                output_options={
                    "markdown": {
                        "tables": {
                            "output_tables_as_markdown": False,
                            "merge_continued_tables": merge_continued_tables,
                        }
                    }
                },
                expand=["items", "markdown"],
            )
            break
        except Exception as exc:
            last_error = exc
            if attempt >= retry_count:
                raise
            wait_seconds = min(2 ** (attempt + 1), 30)
            LOG.warning(
                "Parse attempt %d/%d failed for %s: %s. Retrying in %ss",
                attempt + 1, retry_count + 1, pdf_path.name, exc, wait_seconds
            )
            time.sleep(wait_seconds)

    if result is None:
        raise RuntimeError(f"Parsing failed for {pdf_path}: {last_error}")

    tables = collect_tables(result)
    manifest_tables = []

    for index, table in enumerate(tables, start=1):
        pages = table["page_numbers"]
        if len(pages) >= 2:
            page_label = f"pages_{pages[0]:04d}-{pages[-1]:04d}"
        elif pages:
            page_label = f"page_{pages[0]:04d}"
        else:
            page_label = "page_unknown"

        filename = f"table_{index:04d}_{page_label}.html"
        html_path = tables_dir / filename
        title = f"{pdf_path.stem} — Table {index:04d}"
        html_doc = wrap_table_html(
            table_html=table["html"],
            title=title,
            source_pdf=pdf_path.name,
            pages=pages,
        )
        html_path.write_text(html_doc, encoding="utf-8")

        manifest_tables.append({
            "table_index": index,
            "html_file": str(Path("tables") / filename),
            "source_pdf": pdf_path.name,
            "page_number": table["page_number"],
            "page_numbers": pages,
            "merged_from_pages": table["merged_from_pages"],
            "merged_into_page": table["merged_into_page"],
            "row_count": len(table["rows"]) if table["rows"] else None,
            "column_count": max((len(row) for row in table["rows"] if isinstance(row, list)), default=0)
                if table["rows"] else None,
            "has_html_from_parser": bool(table["html"]),
            "parse_concerns": table["parse_concerns"],
            "bbox": table["bbox"],
        })

    manifest = {
        "source_pdf": str(pdf_path.resolve()),
        "uploaded_file_id": get_value(uploaded_file, "id"),
        "tier": tier,
        "version": version,
        "merge_continued_tables": merge_continued_tables,
        "table_count": len(manifest_tables),
        "tables": manifest_tables,
    }
    (metadata_dir / "tables_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    parse_summary = {
        "source_pdf": str(pdf_path.resolve()),
        "uploaded_file_id": get_value(uploaded_file, "id"),
        "table_count": len(manifest_tables),
        "page_count_returned": len(get_value(get_value(result, "items"), "pages", []) or []),
        "result_metadata": json_safe(result),
    }
    (metadata_dir / "parse_summary.json").write_text(
        json.dumps(parse_summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    LOG.info("Saved %d tables from %s to %s", len(tables), pdf_path.name, tables_dir)
    return {
        "pdf": str(pdf_path),
        "output_directory": str(document_dir),
        "tables_extracted": len(tables),
        "status": "success",
    }


def main() -> int:
    load_dotenv()

    parser = argparse.ArgumentParser(
        description="Extract tables from PDFs using LlamaParse and save each as HTML."
    )
    parser.add_argument("--input", required=True, help="Path to one PDF or a folder of PDFs.")
    parser.add_argument("--output", default="output", help="Output folder (default: ./output).")
    parser.add_argument(
        "--tier", default=os.getenv("LLAMAPARSE_TIER", "agentic_plus"),
        choices=["cost_effective", "agentic", "agentic_plus", "fast"],
        help="LlamaParse tier. agentic_plus is aimed at complex/dense documents."
    )
    parser.add_argument(
        "--version", default=os.getenv("LLAMAPARSE_VERSION", "latest"),
        help="LlamaParse parser version (default: latest)."
    )
    parser.add_argument(
        "--no-merge-continued-tables", action="store_true",
        help="Disable LlamaParse's multi-page continued-table merging."
    )
    parser.add_argument("--recursive", action="store_true", help="Search input folders recursively.")
    parser.add_argument("--retries", type=int, default=2, help="Retries after parse failures (default: 2).")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s | %(levelname)s | %(message)s",
    )

    api_key = os.getenv("LLAMA_CLOUD_API_KEY", "").strip()
    if not api_key:
        LOG.error("Missing LLAMA_CLOUD_API_KEY. Add it to your .env file.")
        return 2

    input_path = Path(args.input).expanduser().resolve()
    output_root = Path(args.output).expanduser().resolve()

    if not input_path.exists():
        LOG.error("Input path does not exist: %s", input_path)
        return 2

    if input_path.is_file():
        if input_path.suffix.lower() != ".pdf":
            LOG.error("Input file must have a .pdf extension: %s", input_path)
            return 2
        pdf_files = [input_path]
    else:
        pattern = "**/*.pdf" if args.recursive else "*.pdf"
        pdf_files = sorted(p for p in input_path.glob(pattern) if p.is_file())

    if not pdf_files:
        LOG.error("No PDF files found at %s", input_path)
        return 2

    client = LlamaCloud(api_key=api_key)
    merge_continued = not args.no_merge_continued_tables
    results = []
    failures = []

    for pdf_path in pdf_files:
        try:
            results.append(
                process_pdf(
                    client=client,
                    pdf_path=pdf_path,
                    output_root=output_root,
                    tier=args.tier,
                    merge_continued_tables=merge_continued,
                    version=args.version,
                    retry_count=max(0, args.retries),
                )
            )
        except Exception as exc:
            LOG.exception("Failed to process %s", pdf_path)
            failures.append({"pdf": str(pdf_path), "error": str(exc), "status": "failed"})

    output_root.mkdir(parents=True, exist_ok=True)
    run_summary = {
        "input": str(input_path),
        "output": str(output_root),
        "pdf_count": len(pdf_files),
        "success_count": len(results),
        "failure_count": len(failures),
        "results": results,
        "failures": failures,
    }
    (output_root / "run_summary.json").write_text(
        json.dumps(run_summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    LOG.info(
        "Finished: %d succeeded, %d failed. Summary: %s",
        len(results), len(failures), output_root / "run_summary.json"
    )
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
