# PDF Table Reconstructor

A modular Python pipeline for classifying financial tables extracted from PDF pages, reconstructing page-spanning tables, and exporting eligible transaction/portfolio-holdings records into Excel.

> **Financial-data caution:** This tool is conservative, but an LLM and heuristics cannot guarantee perfect extraction. Inspect `Review_Log` and reconcile outputs against the source documents before relying on them for financial reporting.

## Features

- Reads `.xlsx`, `.xlsm`, and legacy `.xls` workbooks.
- Supports multiple worksheets and input workbooks.
- Uses an LLM for table classification and ambiguous continuation decisions.
- Supports OpenRouter or Azure OpenAI through `.env`.
- Detects repeated headers and selected headerless continuations.
- Excludes summary-only tables and recognizable subtotal/total rows.
- Preserves source cell values and strings (including leading-zero IDs stored as text).
- Writes compatible logical tables to separate worksheets, plus an audit/review sheet.
- Logs counts and failures without logging API keys or full financial row contents.
- Includes a synthetic sample workbook and unit tests.

## Quick start

Python 3.11+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate       # macOS/Linux
# .venv\Scripts\activate        # Windows
pip install -r requirements.txt
cp .env.example .env
```

For a first test, keep `ENABLE_LLM=false` in `.env`. This exercises the deterministic classification/reconstruction path without API credentials. Then place `sample_input.xlsx` in `input/` (or copy it there) and run:

```bash
python main.py
```

Output: `output/reconstructed_tables.xlsx`.

## Enable OpenRouter

Set in `.env`:

```dotenv
LLM_PROVIDER=openrouter
ENABLE_LLM=true
OPENROUTER_API_KEY=your_key
OPENROUTER_MODEL=openai/gpt-4o-mini
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
```

Choose a model that supports JSON-schema structured output. Some OpenRouter models/providers may not support strict structured output; if so, select a compatible model/provider. The current implementation retries bounded API failures and holds failed classifications for review rather than silently including data.

## Enable Azure OpenAI

Set only the Azure configuration in `.env`:

```dotenv
LLM_PROVIDER=azure_openai
ENABLE_LLM=true
AZURE_OPENAI_API_KEY=your_key
AZURE_OPENAI_ENDPOINT=https://YOUR-RESOURCE.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-10-21
AZURE_OPENAI_DEPLOYMENT=your_deployment_name
```

The Azure deployment name is passed as the `model` argument. Switch providers by changing `.env`; source-code edits are not needed.

## Input workbook conventions

The first non-empty row in each worksheet is treated as its header row. Each worksheet is treated as one extracted table. For reliable page reconstruction, include source metadata. The reader recognizes optional key/value rows at the top of each sheet:

| First cell | Second cell |
|---|---|
| `__source_pdf__` | `annual_statement.pdf` |
| `__page_number__` | `2` |
| `__table_id__` | `transactions_1` |
| `__table_title__` | `Transactions` |

Then put the table header row and data rows below these metadata rows. A file name containing `page_12` can also supply a page number. If source/page metadata is missing, the application intentionally avoids automatic merges based only on matching headers; ambiguous cases go to `Review_Log`.

### Important limitations / assumptions

- Each worksheet represents one candidate extracted table. If a sheet contains several separate tables separated by blank rows, split them into separate worksheets before processing.
- Headerless continuation sheets should have blank cells in the header row and the metadata above it, including a matching source PDF and consecutive page number.
- The sample workbook demonstrates the supported format.
- `.xls` support uses `xlrd`; macros are not executed.
- Excel may already have converted a numeric-looking identifier before this application reads it. To preserve leading zeros, store IDs as text in the source workbook.
- Provider APIs, model names, and structured-output availability can change; check your provider's current model/API documentation.

## Reconstruction algorithm

1. Read sheets and capture workbook/sheet/page metadata.
2. Normalize header strings for comparison without changing original output headers.
3. Classify tables as transactions, holdings, summary, other, or uncertain.
4. Exclude low-confidence/summary/unrelated candidates from business output and log the decision.
5. Sort by known source PDF and page number. Do not infer a page order from filesystem order alone.
6. Merge only when source identity, adjacent page sequence, schema compatibility, and header/column alignment provide sufficient evidence, or when the LLM approves with confidence above `MERGE_CONFIDENCE_THRESHOLD`.
7. Drop repeated header rows and recognizable subtotal/total rows.
8. Keep different schemas in separate output sheets and create valid unique worksheet names.
9. Log exclusions, uncertain decisions, and removed rows in `Review_Log`.

## Tests

```bash
pytest -q
```

Tests cover repeated headers, headerless continuation logic, subtotal detection, schema matching, sheet-name safety, and source value preservation.

## Troubleshooting

- **No files found:** place `.xlsx`, `.xlsm`, or `.xls` files in `INPUT_DIR`.
- **No tables found:** each worksheet needs a non-empty header row and at least some content.
- **LLM authentication failure:** verify only the selected provider's credentials.
- **LLM schema/JSON errors:** choose a model supporting JSON-schema structured output; failed calls are retried and the table is held for review.
- **No automatic merge:** ensure source PDF and page number metadata are accurate and consecutive. This conservative behavior is intentional.
- **Wrong classification in no-LLM mode:** heuristic mode is for pipeline smoke tests; use an LLM and inspect the review sheet for production-oriented classification.

## Project layout

```text
pdf-table-reconstructor/
├── main.py
├── config.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── sample_input.xlsx
├── input/
├── output/
├── src/
│   ├── models.py
│   ├── file_loader.py
│   ├── excel_reader.py
│   ├── metadata_extractor.py
│   ├── table_normalizer.py
│   ├── table_classifier.py
│   ├── continuation_detector.py
│   ├── table_reconstructor.py
│   ├── row_filter.py
│   ├── schema_matcher.py
│   ├── excel_writer.py
│   ├── review_report.py
│   └── llm/
└── tests/
```
