import tempfile
import unittest
from pathlib import Path

sys_path_root = Path(__file__).resolve().parents[1]
import sys
if str(sys_path_root) not in sys.path:
    sys.path.insert(0, str(sys_path_root))

from html_table_merger import (
    candidate_rows_to_drop,
    compatibility_check,
    load_table,
    merge_chain_html,
    validate_merged_html,
)


class CoreMergeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.a = self.root / "page_001_table_01_TRADE_ACTIVITY.html"
        self.b = self.root / "page_002_table_02_TRADE_ACTIVITY_Continued.html"
        self.a.write_text("""<table><tbody>
<tr><td>TRADE ACTIVITY</td><td></td><td></td></tr>
<tr><td>Date</td><td>Description</td><td>Currency</td></tr>
<tr><td>01-Jan</td><td>Payment A</td><td>USD</td></tr>
</tbody></table>""", encoding="utf-8")
        self.b.write_text("""<table><tbody>
<tr><td>TRADE ACTIVITY (Continued)</td><td></td><td></td></tr>
<tr><td>Date</td><td>Description</td><td>Currency</td></tr>
<tr><td>02-Jan</td><td>Payment B</td><td>USD</td></tr>
</tbody></table>""", encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def test_filename_order_parsing(self):
        info = load_table(self.a)
        self.assertEqual(info.page_number, 1)
        self.assertEqual(info.table_number, 1)
        self.assertEqual(info.filename_title, "TRADE ACTIVITY")

    def test_detects_header_and_continuation_banner_for_removal(self):
        a, b = load_table(self.a), load_table(self.b)
        a.classification = {"table_type": "transaction", "confidence": 0.9, "header_row_indices": [1]}
        b.classification = {"table_type": "transaction", "confidence": 0.9, "header_row_indices": [1]}
        drops = candidate_rows_to_drop(a, b)
        self.assertEqual(drops, {0, 1})

    def test_merge_preserves_rows_and_drops_only_confirmed_prefix(self):
        a, b = load_table(self.a), load_table(self.b)
        a.classification = {"table_type": "transaction", "confidence": 0.9, "header_row_indices": [1]}
        b.classification = {"table_type": "transaction", "confidence": 0.9, "header_row_indices": [1]}
        drops = candidate_rows_to_drop(a, b)
        html, _ = merge_chain_html([a, b], {b.filename: drops})
        validation = validate_merged_html([a, b], html, {b.filename: drops})
        self.assertTrue(validation["valid"], validation)
        self.assertEqual(validation["actual_row_count"], 4)
        self.assertIn("Payment B", html)
        self.assertEqual(html.count("Date"), 1)
        self.assertEqual(html.count("TRADE ACTIVITY (Continued)"), 0)

    def test_compatibility_guard_flags_width_mismatch(self):
        a, b = load_table(self.a), load_table(self.b)
        a.classification = {"table_type": "transaction", "confidence": 0.9, "header_row_indices": [1]}
        b.classification = {"table_type": "transaction", "confidence": 0.9, "header_row_indices": [1]}
        b.logical_width = 4
        b.dominant_width = 4
        decision = {"confidence": 0.95}
        ok, reason = compatibility_check(a, b, decision, 0.78)
        self.assertFalse(ok)
        self.assertIn("widths differ", reason)


if __name__ == "__main__":
    unittest.main()
