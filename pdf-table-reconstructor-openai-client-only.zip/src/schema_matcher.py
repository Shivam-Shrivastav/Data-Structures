from .table_normalizer import header_similarity, normalized_headers

def schemas_compatible(a: list[str], b: list[str]) -> bool:
    if len(a) != len(b):
        return False
    sim = header_similarity(a, b)
    return sim >= 0.75

def map_columns(candidate_headers: list[str], original_headers: list[str]) -> list[int] | None:
    """Return candidate index -> original index when a one-to-one mapping is clear."""
    aa, bb = normalized_headers(candidate_headers), normalized_headers(original_headers)
    if len(aa) != len(bb) or any(not x for x in aa) or any(not x for x in bb):
        return None
    mapping = []
    used = set()
    for h in aa:
        matches = [i for i, original in enumerate(bb) if h == original or (len(h) >= 4 and (h in original or original in h))]
        if len(matches) != 1 or matches[0] in used:
            return None
        mapping.append(matches[0])
        used.add(matches[0])
    return mapping
