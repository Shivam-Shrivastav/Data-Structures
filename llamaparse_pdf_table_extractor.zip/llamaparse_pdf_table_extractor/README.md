# LlamaParse PDF Table Extractor

Extract tables from one PDF or a folder of PDFs and save each table as an individual HTML file.

## 1. Requirements

- Python 3.10+
- A LlamaCloud API key for LlamaParse
- Internet access to the LlamaParse service

LlamaParse uses its own hosted parsing service. Microsoft Foundry OpenAI-compatible credentials cannot replace the LlamaCloud key. This implementation does not make a separate OpenAI/Foundry call.

## 2. Setup

```bash
python -m venv .venv
```

Activate the environment:

**macOS/Linux**
```bash
source .venv/bin/activate
```

**Windows PowerShell**
```powershell
.venv\Scripts\Activate.ps1
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and set:

```dotenv
LLAMA_CLOUD_API_KEY=your_llama_cloud_api_key
```

Do not commit `.env` to source control.

## 3. Run

One PDF:

```bash
python llamaparse_pdf_tables.py --input "/path/to/confirmation.pdf" --output "./output"
```

All PDFs directly inside a folder:

```bash
python llamaparse_pdf_tables.py --input "/path/to/pdfs" --output "./output"
```

Include nested folders:

```bash
python llamaparse_pdf_tables.py --input "/path/to/pdfs" --output "./output" --recursive
```

For dense financial/audit PDFs, the default tier is `agentic_plus`. You can choose another tier:

```bash
python llamaparse_pdf_tables.py --input "./pdfs" --tier agentic --output "./output"
```

Disable merging of tables that continue across pages:

```bash
python llamaparse_pdf_tables.py --input "./pdfs" --no-merge-continued-tables
```

## 4. Output structure

```text
output/
  run_summary.json
  confirmation_pdf/
    tables/
      table_0001_page_0001.html
      table_0002_page_0002.html
      table_0003_pages_0003-0004.html
    metadata/
      tables_manifest.json
      parse_summary.json
```

- `tables/*.html`: one standalone HTML file per detected table.
- `tables_manifest.json`: table index, source pages, row/column counts, merge metadata, bounding box, and parser concerns.
- `parse_summary.json`: parse metadata and returned item structure.
- `run_summary.json`: overall run success/failure summary.

## 5. Notes and limitations

- The script requests typed `table` items rather than trying to scrape tables from Markdown.
- It requests HTML table output so that `rowspan`/`colspan` can be preserved when provided by LlamaParse.
- Continued-table merging is enabled by default. The parser may not identify every continuation perfectly; inspect `merged_from_pages` and `parse_concerns` in the manifest.
- The HTML table content is taken from LlamaParse's `table.html`. The wrapper adds a title, source PDF, page information, and basic styling.
- Very large PDFs can take significant time and incur service usage costs. Consider testing on a small sample first.
- The script writes a parse summary JSON which can be large for very long PDFs. If storage is a concern, remove the `parse_summary.json` write in `process_pdf()` or replace it with a smaller metadata summary.
