import json, time, logging
from openai import OpenAI
from .base import LLMProvider

log = logging.getLogger(__name__)

CLASSIFY_SCHEMA = {
    "type":"object",
    "properties":{
        "table_type":{"type":"string","enum":["transaction","portfolio_holdings","summary","other","uncertain"]},
        "include_table":{"type":"boolean"},
        "reasoning_summary":{"type":"string"},
        "detected_header":{"type":"array","items":{"type":"string"}},
        "contains_detail_rows":{"type":"boolean"},
        "contains_subtotals":{"type":"boolean"},
        "confidence":{"type":"number","minimum":0,"maximum":1},
        "review_required":{"type":"boolean"}
    },
    "required":["table_type","include_table","reasoning_summary","detected_header","contains_detail_rows","contains_subtotals","confidence","review_required"],
    "additionalProperties":False
}
MERGE_SCHEMA = {
    "type":"object",
    "properties":{
        "decision":{"type":"string","enum":["merge","start_new_table","uncertain"]},
        "target_table_id":{"type":["string","null"]},
        "header_present":{"type":"boolean"},
        "header_matches_existing":{"type":"boolean"},
        "header_mapping":{"type":"array","items":{"type":"integer"}},
        "rows_to_remove":{"type":"array","items":{"type":"object","properties":{"row_index":{"type":"integer"},"reason":{"type":"string"}},"required":["row_index","reason"],"additionalProperties":False}},
        "reasoning_summary":{"type":"string"},
        "confidence":{"type":"number","minimum":0,"maximum":1},
        "review_required":{"type":"boolean"}
    },
    "required":["decision","target_table_id","header_present","header_matches_existing","header_mapping","rows_to_remove","reasoning_summary","confidence","review_required"],
    "additionalProperties":False
}

class OpenRouterProvider(LLMProvider):
    def __init__(self, config):
        self.config = config
        self.client = OpenAI(api_key=config.openrouter_api_key, base_url=config.openrouter_base_url,
                             timeout=config.llm_timeout_seconds, max_retries=0)

    def _json_call(self, system, payload, schema, name):
        last = None
        for attempt in range(self.config.max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=self.config.openrouter_model,
                    messages=[{"role":"system","content":system},
                              {"role":"user","content":json.dumps(payload, ensure_ascii=False, default=str)}],
                    response_format={"type":"json_schema","json_schema":{"name":name,"strict":True,"schema":schema}},
                )
                content = response.choices[0].message.content
                result = json.loads(content)
                if not isinstance(result, dict):
                    raise ValueError("LLM response was not a JSON object")
                return result
            except Exception as exc:
                last = exc
                log.warning("LLM request failed (attempt %s/%s): %s", attempt+1, self.config.max_retries, type(exc).__name__)
                if attempt + 1 < self.config.max_retries:
                    time.sleep(min(2 ** attempt, 4))
        raise RuntimeError(f"LLM request failed after retries: {type(last).__name__}") from last

    def classify_table(self, table_context):
        return self._json_call(
            "Classify financial extracted tables by actual row-level meaning. Include only individual transaction records or individual portfolio asset/holding records. Exclude summaries, aggregate-only tables, reference data and unrelated tables. Do not infer missing data. If uncertain, set uncertain and review_required=true.",
            table_context, CLASSIFY_SCHEMA, "table_classification")

    def decide_table_continuation(self, previous_table, candidate_table):
        return self._json_call(
            "Decide whether the candidate is a continuation of the prior logical financial table. Use source identity, page order, title, schema, column count, row patterns and section context. Matching headers alone is insufficient. Never invent or rewrite financial values. Use merge only with strong evidence; otherwise uncertain or start_new_table. header_mapping is candidate-column index to original-column index.",
            {"previous_table":previous_table,"candidate_table":candidate_table}, MERGE_SCHEMA, "table_continuation")
