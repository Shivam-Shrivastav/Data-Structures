import re
from .models import SourceTable

def norm_text(value) -> str:
    if value is None:
        return ""
    s = str(value).replace("\n", " ").replace("\r", " ")
    s = re.sub(r"\s+", " ", s).strip().lower()
    return s

def normalize_header(value) -> str:
    s = norm_text(value)
    s = re.sub(r"[^a-z0-9%$]+", "", s)
    return s

def normalized_headers(headers: list[str]) -> list[str]:
    return [normalize_header(h) for h in headers]

def is_headerless(table: SourceTable) -> bool:
    nonblank = [h for h in table.headers if norm_text(h)]
    return len(nonblank) == 0 or all(re.fullmatch(r"unnamed:?\s*\d*", norm_text(h) or "") for h in nonblank)

def header_similarity(a: list[str], b: list[str]) -> float:
    aa, bb = normalized_headers(a), normalized_headers(b)
    if not aa or len(aa) != len(bb):
        return 0.0
    same = sum(bool(x == y or (x and y and (x in y or y in x))) for x, y in zip(aa, bb))
    return same / len(aa)

def schema_signature(headers: list[str]) -> tuple[str, ...]:
    return tuple(normalized_headers(headers))
