from __future__ import annotations
import argparse, json, logging, os, re, traceback
from pathlib import Path
from typing import Any
import fitz
import pandas as pd
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("pdf_table_extractor")

def safe(v):
    if v is None or isinstance(v, (str, int, float, bool)): return v
    if isinstance(v, dict): return {str(k): safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [safe(x) for x in v]
    if hasattr(v, "model_dump"):
        try: return safe(v.model_dump(exclude_none=True))
        except Exception: pass
    if hasattr(v, "to_dict"):
        try: return safe(v.to_dict())
        except Exception: pass
    return str(v)

def clean(v): return re.sub(r"\s+", " ", str(v or "")).strip()

def rows_normalize(rows):
    out=[]
    for row in rows or []:
        if hasattr(row, "tolist"): row=row.tolist()
        if not isinstance(row, (list, tuple)): row=[row]
        out.append([clean(x) for x in row])
    width=max((len(r) for r in out), default=0)
    return [r+[""]*(width-len(r)) for r in out]

def page_count(pdf):
    with fitz.open(pdf) as d: return len(d)

def page_text(pdf, n, max_lines=18):
    try:
        with fitz.open(pdf) as d: txt=d[n-1].get_text("text") if 1 <= n <= len(d) else ""
        lines=[clean(x) for x in txt.splitlines()]
        return "\n".join(x for x in lines if x)[:5000] if lines else ""
    except Exception as e:
        log.warning("Page text failed (%s page %s): %s", pdf.name, n, e); return ""

def safe_name(s, limit=75):
    s=re.sub(r"[^\w\- ]+", "", s, flags=re.UNICODE)
    return (re.sub(r"[\s\-]+", "_", s).strip("_")[:limit] or "untitled_table")

def infer_title(client, model, page_opening, rows, fallback=None):
    if not client:
        return fallback, "Skipped: OPENAI_API_KEY not configured."
    preview="\n".join(" | ".join(r) for r in rows[:8])
    prompt=f"""You name tables extracted from audit confirmation documents.
Return only JSON: {{"title": string or null, "reason": short string}}.
Identify the descriptive title/caption/section heading, NOT column names.
Use nearby page text and table content. Do not invent a title. If only column
labels/data are available, return null. Preserve meaningful portfolio,
transaction, broker, bank, account or instrument names.

Opening lines of page:
{page_opening[:5000]}

Extracted table preview:
{preview[:5000]}"""
    try:
        text=client.responses.create(model=model, input=prompt).output_text.strip()
        text=re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
        obj=json.loads(text)
        return clean(obj.get("title")) or fallback, clean(obj.get("reason"))
    except Exception as e:
        log.warning("OpenAI title inference failed: %s", e)
        return fallback, f"Title inference failed: {type(e).__name__}: {e}"

def output_dirs(root, engine):
    d={k:root/engine/k for k in ("json","md","xlsx")}
    for p in d.values(): p.mkdir(parents=True, exist_ok=True)
    return d

def write_one(t, dirs):
    title=t.get("inferred_title") or t.get("native_title") or f"Table_{t['table_number_on_page']}"
    stem=f"page_{t['page_number']:03d}_table_{t['table_number_on_page']:02d}_{safe_name(title)}"
    payload={**t, "table_title":title,
             "row_count":len(t["rows"]),
             "max_column_count":max((len(r) for r in t["rows"]), default=0)}
    (dirs["json"]/f"{stem}.json").write_text(json.dumps(safe(payload), ensure_ascii=False, indent=2), encoding="utf-8")
    lines=[f"# {title}", "", f"- **Source:** `{t['source_file']}`",
           f"- **Extractor:** `{t['engine']}`", f"- **Page:** {t['page_number']}",
           f"- **Table index on page:** {t['table_number_on_page']}", "",
           "## Page opening text", "", t.get("page_opening_text") or "_No text extracted._",
           "", "## Extracted table", ""]
    rr=t["rows"]
    if rr:
        w=max(map(len,rr)); rr=[r+[""]*(w-len(r)) for r in rr]
        lines += ["| "+" | ".join(x.replace("|", r"\|") for x in rr[0])+" |",
                  "| "+" | ".join(["---"]*w)+" |"]
        lines += ["| "+" | ".join(x.replace("|", r"\|") for x in r)+" |" for r in rr[1:]]
    else: lines.append("_No rows extracted._")
    lines += ["", "> The first row is shown as a Markdown header for readability only. JSON preserves all rows without assuming a header.", "",
              "## Metadata", "", "```json", json.dumps(safe(t.get("extraction_metadata",{})), ensure_ascii=False, indent=2), "```", ""]
    (dirs["md"]/f"{stem}.md").write_text("\n".join(lines), encoding="utf-8")
    with pd.ExcelWriter(dirs["xlsx"]/f"{stem}.xlsx", engine="openpyxl") as xw:
        pd.DataFrame(t["rows"]).to_excel(xw, index=False, header=False, sheet_name="ExtractedTable")
        metadata=[["source_file",t["source_file"]],["engine",t["engine"]],
                  ["page_number",t["page_number"]],["table_number_on_page",t["table_number_on_page"]],
                  ["table_title",title],["bbox",json.dumps(t.get("bbox"))],
                  ["native_title",t.get("native_title") or ""],["title_reason",t.get("title_reason") or ""]]
        pd.DataFrame(metadata,columns=["field","value"]).to_excel(xw,index=False,sheet_name="Metadata")

def finish(pdf, engine, tables, root, ai, model):
    dirs=output_dirs(root,engine)
    for t in tables:
        t["page_opening_text"]=t.get("page_opening_text") or page_text(pdf,t["page_number"])
        t["inferred_title"], t["title_reason"]=infer_title(ai,model,t["page_opening_text"],t["rows"],t.get("native_title"))
        write_one(t,dirs)
    n=page_count(pdf); pages={t["page_number"] for t in tables}
    manifest={"source_file":pdf.name,"engine":engine,"pages_in_pdf":n,
              "tables_extracted":len(tables),"pages_with_tables":sorted(pages),
              "pages_without_detected_tables":sorted(set(range(1,n+1))-pages),
              "cross_page_merging_performed":False}
    (root/engine/f"{safe_name(pdf.stem)}_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return len(tables)

def extract_camelot(pdf):
    import camelot
    out=[]; n=page_count(pdf)
    for p in range(1,n+1):
        found=[]; flavor_used=None; errors=[]
        for flavor in ("lattice","stream"):
            try:
                tables=camelot.read_pdf(str(pdf),pages=str(p),flavor=flavor,suppress_stdout=True)
                if len(tables): found=list(tables); flavor_used=flavor; break
            except Exception as e: errors.append(f"{flavor}: {type(e).__name__}: {e}")
        for i,t in enumerate(found,1):
            df=t.df; bbox=None
            try: bbox=[float(x) for x in t._bbox]
            except Exception: pass
            out.append({"source_file":pdf.name,"engine":"camelot","page_number":p,
                "table_number_on_page":i,"rows":rows_normalize(df.values.tolist()),"bbox":bbox,
                "page_opening_text":page_text(pdf,p),"native_title":None,
                "extraction_metadata":{"flavor":flavor_used,"shape":list(df.shape),
                  "parsing_report":safe(getattr(t,"parsing_report",{})),"fallback_errors":errors}})
        log.info("Camelot page %s/%s: %s table(s)",p,n,len(found))
    return out

def extract_docling(pdf):
    from docling.document_converter import DocumentConverter
    doc=DocumentConverter().convert(str(pdf)).document
    out=[]; counters={}
    for table in getattr(doc,"tables",[]) or []:
        try: df=table.export_to_dataframe(doc=doc); rows=rows_normalize(df.values.tolist())
        except Exception as e:
            log.warning("Docling dataframe export failed: %s",e); rows=[]
        prov=getattr(table,"prov",None) or []; pages=[]; bbox=None
        for pr in prov:
            pn=getattr(pr,"page_no",None)
            if pn is not None:
                try: pages.append(int(pn))
                except Exception: pass
            b=getattr(pr,"bbox",None)
            if b is not None and bbox is None:
                try: bbox=[float(getattr(b,k)) for k in ("l","t","r","b")]
                except Exception: pass
        pages=sorted(set(p for p in pages if 1 <= p <= page_count(pdf)))
        note=None
        if not pages: pages=[1]; note="No page provenance; assigned to page 1 as fallback."
        p=pages[0]; counters[p]=counters.get(p,0)+1
        native=None
        try:
            caps=getattr(table,"captions",None) or []
            if caps: native=clean(getattr(caps[0],"text",caps[0])) or None
        except Exception: pass
        extra={"provenance_pages":pages,"page_attribution_note":note,
               "self_ref":str(getattr(table,"self_ref",""))}
        try: extra["table_html"]=table.export_to_html(doc=doc)
        except Exception: pass
        try: extra["table_markdown"]=table.export_to_markdown(doc=doc)
        except Exception: pass
        out.append({"source_file":pdf.name,"engine":"docling","page_number":p,
            "table_number_on_page":counters[p],"rows":rows,"bbox":bbox,
            "page_opening_text":page_text(pdf,p),"native_title":native,"extraction_metadata":extra})
    log.info("Docling detected %s table(s)",len(out))
    return out

def extract_azure(pdf):
    from azure.ai.documentintelligence import DocumentIntelligenceClient
    from azure.core.credentials import AzureKeyCredential
    endpoint=os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    key=os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    if not endpoint or not key:
        raise RuntimeError("Set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and AZURE_DOCUMENT_INTELLIGENCE_KEY in .env")
    client=DocumentIntelligenceClient(endpoint=endpoint,credential=AzureKeyCredential(key))
    with open(pdf,"rb") as f:
        result=client.begin_analyze_document("prebuilt-layout",body=f).result()
    out=[]; counters={}
    for table in getattr(result,"tables",[]) or []:
        cells=getattr(table,"cells",[]) or []; byrow={}; maxr=maxc=-1
        for c in cells:
            r=int(getattr(c,"row_index",0) or 0); col=int(getattr(c,"column_index",0) or 0)
            maxr=max(maxr,r); maxc=max(maxc,col)
            byrow.setdefault(r,{})[col]=clean(getattr(c,"content",""))
        rows=[[byrow.get(r,{}).get(c,"") for c in range(maxc+1)] for r in range(maxr+1)]
        regions=getattr(table,"bounding_regions",[]) or []; pages=[]; bbox=None
        for reg in regions:
            pn=getattr(reg,"page_number",None)
            if pn is not None: pages.append(int(pn))
            poly=getattr(reg,"polygon",None)
            if poly and bbox is None:
                xs=[float(x.x) for x in poly if getattr(x,"x",None) is not None]
                ys=[float(x.y) for x in poly if getattr(x,"y",None) is not None]
                if xs and ys: bbox=[min(xs),min(ys),max(xs),max(ys)]
        pages=sorted(set(pages)); p=pages[0] if pages else 1
        counters[p]=counters.get(p,0)+1
        out.append({"source_file":pdf.name,"engine":"azure","page_number":p,
            "table_number_on_page":counters[p],"rows":rows_normalize(rows),"bbox":bbox,
            "page_opening_text":page_text(pdf,p),"native_title":None,
            "extraction_metadata":{"row_count":getattr(table,"row_count",len(rows)),
              "column_count":getattr(table,"column_count",maxc+1),"provenance_pages":pages,
              "native_table":safe(table)}})
    log.info("Azure Document Intelligence detected %s table(s)",len(out))
    return out

def find_pdfs(path):
    if path.is_file() and path.suffix.lower()==".pdf": return [path]
    if path.is_dir(): return sorted(x for x in path.rglob("*") if x.is_file() and x.suffix.lower()==".pdf")
    raise FileNotFoundError(f"PDF or directory not found: {path}")

def main():
    parser=argparse.ArgumentParser(description="Compare PDF table extraction engines.")
    parser.add_argument("engine",choices=["camelot","docling","azure"])
    parser.add_argument("input",help="A PDF file or directory containing PDFs")
    parser.add_argument("--output",default="outputs")
    parser.add_argument("--openai-model",default=os.getenv("OPENAI_MODEL","gpt-4.1-mini"))
    args=parser.parse_args(); src=Path(args.input).expanduser().resolve(); root=Path(args.output).expanduser().resolve()
    pdfs=find_pdfs(src)
    # Microsoft Foundry OpenAI-compatible endpoint configuration.
    # FOUNDRY_OPENAI_ENDPOINT should include the complete OpenAI-compatible base URL,
    # e.g. https://<resource>.openai.azure.com/openai/v1/
    # For a Foundry project endpoint, use the project endpoint's OpenAI-compatible
    # route as documented for your resource.
    foundry_endpoint = os.getenv("FOUNDRY_OPENAI_ENDPOINT", "").strip()
    foundry_key = os.getenv("FOUNDRY_OPENAI_API_KEY", "").strip()

    # Backward-compatible fallback to the public OpenAI API if no Foundry endpoint
    # is configured. If a Foundry endpoint is set, use its key and base_url.
    if foundry_endpoint:
        api_key = foundry_key or os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key:
            raise RuntimeError(
                "FOUNDRY_OPENAI_ENDPOINT is set, but FOUNDRY_OPENAI_API_KEY "
                "(or fallback OPENAI_API_KEY) is missing."
            )
        ai = OpenAI(base_url=foundry_endpoint, api_key=api_key)
    else:
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        ai = OpenAI(api_key=api_key) if api_key else None

    model = os.getenv("FOUNDRY_OPENAI_MODEL") or os.getenv("OPENAI_MODEL") or args.openai_model
    if not ai:
        log.warning("No OpenAI/Foundry API key configured; extraction continues without AI title inference.")
    extractor={"camelot":extract_camelot,"docling":extract_docling,"azure":extract_azure}[args.engine]
    total=0; failures=[]
    for pdf in pdfs:
        try:
            log.info("Processing %s with %s",pdf.name,args.engine)
            count=finish(pdf,args.engine,extractor(pdf),root,ai,model); total+=count
            log.info("Wrote %s table(s) for %s",count,pdf.name)
        except Exception as e:
            log.exception("Failed on %s",pdf)
            failures.append({"file":str(pdf),"error":f"{type(e).__name__}: {e}","traceback":traceback.format_exc()})
    root.mkdir(parents=True,exist_ok=True)
    (root/f"{args.engine}_run_summary.json").write_text(json.dumps({"engine":args.engine,"pdf_count":len(pdfs),"tables_written":total,"failures":failures},indent=2),encoding="utf-8")
    log.info("Complete: %s table(s), %s failure(s)",total,len(failures))
    return 1 if failures and total==0 else 0

if __name__=="__main__": raise SystemExit(main())
