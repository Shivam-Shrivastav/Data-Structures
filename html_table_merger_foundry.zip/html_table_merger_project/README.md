# HTML Financial Table Merger (Microsoft Foundry)

A reusable pipeline for classifying page-level HTML tables and merging only transaction and portfolio-holding tables across consecutive PDF pages. Microsoft Foundry (through the standard `openai` Python library) is used for classification and ambiguous continuation decisions. Python handles HTML parsing, row append operations, structural guards, validation, XLSX export, and audit reporting.

## Important safety behavior

- Input files are never modified.
- The input folder should contain HTML tables from **one source PDF**. The current filename convention does not reliably identify a PDF when files from multiple PDFs are mixed.
- Tables classified confidently as `summary` or `other` are excluded from final merged outputs.
- A continuation is accepted only when the LLM confidence exceeds the configured threshold and Python's page/type/column-width checks pass.
- A candidate with a materially different logical width is flagged for review instead of being force-merged. Automatic semantic column splitting/mapping is deliberately not attempted because it could corrupt financial data.
- Only exact/reliably similar repeated headers, obvious “continued” banner rows, and empty rows are removed from a continuation table. Arbitrary prefix rows are not dropped just because the model thinks they may be irrelevant.
- Low-confidence table classifications, ambiguous continuation pairs, and structural failures appear in `reports/review_required.csv` and `reports/merge_report.json`.
- Outputs are written as HTML and XLSX. XLSX includes `Merged Table`, `Provenance`, and `Validation` sheets.

## 1. Install

Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS/Linux
# source .venv/bin/activate

pip install -r requirements.txt
```

## 2. Configure Microsoft Foundry

Copy `.env.example` to `.env` and populate the endpoint, API key, and model deployment name.

```env
FOUNDRY_OPENAI_ENDPOINT=https://YOUR-RESOURCE-NAME.openai.azure.com/openai/v1/
FOUNDRY_OPENAI_API_KEY=YOUR_KEY
FOUNDRY_OPENAI_MODEL=YOUR_MODEL_DEPLOYMENT_NAME
```

The endpoint should be the OpenAI-compatible v1 endpoint for your Foundry resource. The deployment name is passed as the `model` value. Responses API is attempted first; the code falls back to Chat Completions for deployments that do not support Responses.

## 3. Run

Pass the folder containing the per-table HTML files (for example, your `outputs/azure/html` folder):

```bash
python html_table_merger.py "C:\\path\\to\\outputs\\azure\\html" --output "C:\\path\\to\\merge_outputs"
```

Optional thresholds:

```bash
python html_table_merger.py ./outputs/azure/html --output ./merge_outputs --classification-threshold 0.70 --merge-threshold 0.78 --log-level INFO
```

- `--classification-threshold`: relevant table types below this confidence are flagged and not automatically used as chain starters.
- `--merge-threshold`: continuation decisions below this confidence are flagged instead of being merged.

## 4. Output

```text
merge_outputs/
├── merged/
│   ├── html/       # one HTML per logical transaction/holdings table
│   └── xlsx/       # matching Excel workbooks
└── reports/
    ├── merge_report.json
    └── review_required.csv
```

Output names preserve the starting table's descriptive filename and add a sequence number and page range, e.g. `merged_001_TRADE_ACTIVITY_pages_006-022.html`.

## Merge logic

1. Parse the HTML table, read the initial rows, and infer page/table order from names like `page_006_table_03_TRADE_ACTIVITY.html`.
2. Ask Foundry to classify each table as `transaction`, `portfolio_holding`, `summary`, `other`, or `uncertain`.
3. For each confidently relevant table, compare plausible tables on the immediately following page. The LLM can select a continuation even if unrelated tables appear earlier on that page or if the continuation has no visible header.
4. Check that pages are consecutive, table types are compatible, and dominant logical row widths match. Width mismatches are routed to review rather than guessed.
5. Append original HTML `<tr>` elements. Drop only verified duplicate header rows, obvious continuation banners, and empty leading rows.
6. Reparse the result and check row count, row order, and source-cell text preservation. Only validated results are exported.
7. Generate XLSX and a review/audit report.

## Current limitations

- This first version expects page order encoded in filenames. Files with unparseable page numbers can be classified, but cannot be automatically chained.
- It compares tables only across consecutive pages. It deliberately does not jump over pages where no table was extracted.
- Column remapping when extraction engines split/merge columns is not automatic; these cases are flagged for review.
- `rowspan` and `colspan` are accounted for in width/grid calculations and retained in the HTML cells, but Excel output is a normalized value grid and does not reproduce every visual span as Excel merged cells.
- An LLM confidence value is not a calibrated probability. Tune thresholds on a labeled sample of your actual PDFs before production use.

## Tests

```bash
python -m unittest discover -s tests -v
```
