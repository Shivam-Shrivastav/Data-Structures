# Audit PDF Table Extractor Comparison

Three independent extractors for heterogeneous audit confirmation PDFs:
- Camelot
- Docling
- Azure AI Document Intelligence

## Install

Python 3.10+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate        # macOS/Linux
# .venv\\Scripts\\activate     # Windows
pip install -r requirements.txt
cp .env.example .env
```

Fill in `.env`. OpenAI title inference is optional. Azure credentials are required only for the Azure command.

**Confidentiality:** audit confirmation PDFs may contain sensitive financial information. Only send page/table excerpts to OpenAI if approved by your organisation. If not approved, omit `OPENAI_API_KEY`; extraction still runs with fallback table names.

## Run one library at a time

```bash
python pdf_table_extractor.py camelot ./input_pdfs
python pdf_table_extractor.py docling ./input_pdfs
python pdf_table_extractor.py azure ./input_pdfs
```

One PDF is also supported:

```bash
python pdf_table_extractor.py camelot ./input_pdfs/broker_a.pdf
```

Custom output root:

```bash
python pdf_table_extractor.py docling ./input_pdfs --output comparison_outputs
```

## Output layout

```text
outputs/
  camelot/
    json/
    md/
    xlsx/
  docling/
    json/
    md/
    xlsx/
  azure/
    json/
    md/
    xlsx/
```

Each table is written as one JSON, one Markdown, and one XLSX file. Filenames include page number, table index on page, and inferred descriptive title. Each XLSX has an `ExtractedTable` sheet with raw cells and a `Metadata` sheet. No first row is assumed to be a header.

JSON preserves rows, empty cells, page opening text, bounding box where available, extraction metadata, title inference reason, and provenance pages where exposed.

## Scope and limitations

- Page-wise extraction only; cross-page merging is intentionally not implemented yet.
- Camelot tries `lattice`, then falls back to `stream` only if lattice finds no table on that page. This is a baseline, not an exhaustive search of every parser.
- Docling/Azure may return a table with provenance spanning multiple pages. This version writes it once, attributed to the first provenance page, and records all provenance pages in JSON.
- Pages with no detected tables are listed in a per-PDF manifest.
- The OpenAI title is an inference, not guaranteed truth. Review titles during the comparison.
- Library outputs are not perfectly equivalent; native metadata is retained where practical.

## Compare engines on the same PDFs

Compare detected table count, missing/duplicated rows, blank cells, column boundaries, multi-row headers, page attribution, title quality, processing time, and Azure cost. JSON is the detailed comparison artifact.
