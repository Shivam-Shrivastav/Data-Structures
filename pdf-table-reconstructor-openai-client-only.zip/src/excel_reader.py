from pathlib import Path
import pandas as pd
from openpyxl import load_workbook
from .models import SourceTable
from .metadata_extractor import metadata_from

META_KEYS = {
    "__source_pdf__": "source_pdf",
    "__page_number__": "page_number",
    "__table_id__": "table_identifier",
    "__table_title__": "title",
}

def _clean(v):
    if pd.isna(v):
        return None
    # Keep strings as strings; especially preserve identifiers with leading zeros.
    if isinstance(v, str):
        return v.strip()
    return v

def _parse_page_value(value):
    try:
        return int(value)
    except (ValueError, TypeError):
        return None

def read_workbook(path: Path) -> list[SourceTable]:
    tables = []
    # pandas reads values; openpyxl provides properties and sheet enumeration.
    if path.suffix.lower() == ".xls":
        xls = pd.ExcelFile(path, engine="xlrd")
        sheet_names = xls.sheet_names
        workbook = None
    else:
        workbook = load_workbook(path, read_only=True, data_only=True)
        sheet_names = workbook.sheetnames

    for sheet_name in sheet_names:
        try:
            raw = pd.read_excel(path, sheet_name=sheet_name, header=None,
                                dtype=object, engine="xlrd" if path.suffix.lower()==".xls" else "openpyxl")
        except Exception as exc:
            raise ValueError(f"Could not read {path.name}/{sheet_name}: {exc}") from exc
        if raw.empty:
            continue
        raw = raw.where(pd.notna(raw), None)
        # Optional metadata may be supplied in first two columns as key/value rows.
        metadata = metadata_from(path, sheet_name, workbook)
        start = 0
        for idx in range(min(8, len(raw))):
            key = str(raw.iat[idx, 0]).strip().lower() if raw.shape[1] and raw.iat[idx, 0] is not None else ""
            if key in META_KEYS and raw.shape[1] > 1:
                val = raw.iat[idx, 1]
                target = META_KEYS[key]
                if target == "page_number":
                    metadata[target] = _parse_page_value(val)
                else:
                    metadata[target] = str(val).strip() if val is not None else None
                start = idx + 1
            elif key and key.startswith("__"):
                continue
            else:
                break
        raw = raw.iloc[start:].reset_index(drop=True)
        if raw.empty:
            continue
        # The first row after metadata is the header row, even if all its cells are blank.
        # This is how a headerless continuation is represented. Blank rows after the header
        # are handled as ordinary empty rows below.
        header_idx = 0 if len(raw) else None
        if header_idx is None:
            continue
        header_values = [_clean(v) for v in raw.iloc[header_idx].tolist()]
        # Drop only fully empty trailing columns; do not drop interior blanks.
        while header_values and header_values[-1] is None:
            header_values.pop()
        if not header_values:
            continue
        headers = [str(v).replace("\n", " ").strip() if v is not None else "" for v in header_values]
        data = raw.iloc[header_idx+1:, :len(headers)]
        rows, row_indices = [], []
        for ix, row in data.iterrows():
            vals = [_clean(v) for v in row.tolist()[:len(headers)]]
            vals += [None] * (len(headers)-len(vals))
            if all(v is None or (isinstance(v, str) and not v.strip()) for v in vals):
                continue
            rows.append(vals)
            row_indices.append(int(ix) + start + header_idx + 2)  # Excel 1-based row
        tables.append(SourceTable(
            table_id=f"{path.stem}::{sheet_name}",
            source_file=path.name,
            sheet_name=sheet_name,
            source_pdf=metadata.get("source_pdf"),
            page_number=metadata.get("page_number"),
            table_identifier=metadata.get("table_identifier"),
            title=metadata.get("title"),
            headers=headers,
            rows=rows,
            original_row_indices=row_indices,
            metadata=metadata,
        ))
    if workbook is not None:
        workbook.close()
    return tables
