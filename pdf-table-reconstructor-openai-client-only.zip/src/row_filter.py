import re

TOTAL_RE = re.compile(r"\b(sub[\s-]?total|grand total|total purchases|total sales|total market value|net total|total)\b", re.I)

def is_total_row(row: list, headers: list[str]) -> bool:
    nonempty = [(i, str(v).strip()) for i, v in enumerate(row) if v is not None and str(v).strip()]
    if not nonempty:
        return False
    first_values = [v.lower() for _, v in nonempty[:2]]
    # Only classify as subtotal/total when label is a leading descriptor or appears in a
    # description/summary-like column; don't reject a row because a detail value says "interest".
    label = " ".join(first_values)
    if TOTAL_RE.search(label):
        first_text = first_values[0]
        if TOTAL_RE.search(first_text) and (len(nonempty) <= 3 or first_text.startswith(("total", "subtotal", "sub-total", "grand total", "net total"))):
            return True
    for i, value in nonempty[:2]:
        h = str(headers[i]).lower() if i < len(headers) else ""
        if any(k in h for k in ("description", "activity", "security", "holding", "name", "category")):
            if value.strip().lower() in {"total", "subtotal", "sub-total", "grand total", "net total", "total purchases", "total sales", "total market value"}:
                return True
    return False

def remove_duplicate_header_rows(rows: list[list], headers: list[str]) -> tuple[list[list], list[dict]]:
    from .table_normalizer import header_similarity
    kept, removed = [], []
    for i, row in enumerate(rows):
        candidate = ["" if v is None else str(v) for v in row]
        if header_similarity(headers, candidate) >= 0.8:
            removed.append({"row_index": i, "reason": "Repeated column header"})
        else:
            kept.append(row)
    return kept, removed
