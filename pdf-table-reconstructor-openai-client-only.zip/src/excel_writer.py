import re
from pathlib import Path
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

INVALID = re.compile(r'[\\/*?:\[\]]')

def safe_sheet_name(name: str, used: set[str]) -> str:
    base = INVALID.sub("_", str(name or "Table")).strip("' ")[:31] or "Table"
    candidate = base
    i = 2
    while candidate.lower() in {x.lower() for x in used}:
        suffix = f"_{i}"
        candidate = base[:31-len(suffix)] + suffix
        i += 1
    used.add(candidate)
    return candidate

def _title(logical):
    title = logical.title or ("Transactions" if logical.table_type=="transaction" else "Portfolio_Holdings")
    return title

def write_output(logical_tables, review_rows, output_path: Path, enable_review=True):
    output_path.parent.mkdir(parents=True, exist_ok=True)
    used = set()
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for table in logical_tables:
            name = safe_sheet_name(_title(table), used)
            df = pd.DataFrame(table.rows, columns=table.headers)
            # Write as objects; strings such as IDs with leading zeros remain strings.
            df.to_excel(writer, sheet_name=name, index=False)
        if enable_review:
            name = safe_sheet_name("Review_Log", used)
            review_df = pd.DataFrame(review_rows)
            if review_df.empty:
                review_df = pd.DataFrame(columns=["action","source_file","sheet_name","table_id","reason","confidence","review_required"])
            review_df.to_excel(writer, sheet_name=name, index=False)
    wb = load_workbook(output_path)
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="244062")
            cell.alignment = Alignment(wrap_text=True, vertical="top")
        for col in ws.columns:
            max_len = min(48, max(10, max((len(str(c.value)) if c.value is not None else 0) for c in col[:200]) + 2))
            ws.column_dimensions[get_column_letter(col[0].column)].width = max_len
    wb.save(output_path)
