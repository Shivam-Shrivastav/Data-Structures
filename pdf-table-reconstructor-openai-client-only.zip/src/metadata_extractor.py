import re
from pathlib import Path

def metadata_from(path: Path, sheet_name: str, workbook=None) -> dict:
    """Read conventional metadata from workbook properties and filenames/sheet names.

    Recommended optional metadata columns, when present in a table's first rows:
    __source_pdf__, __page_number__, __table_id__, __table_title__.
    Filename patterns like report_page_12_table_2.xlsx are also recognized.
    """
    name = path.stem
    page = None
    table_id = None
    m = re.search(r"(?:page|p)[_-]?(\d+)", name, re.I)
    if m:
        page = int(m.group(1))
    mt = re.search(r"(?:table|tbl)[_-]?(\d+)", name, re.I)
    if mt:
        table_id = mt.group(1)
    props = {}
    if workbook is not None:
        try:
            props = {
                "creator": workbook.properties.creator,
                "subject": workbook.properties.subject,
                "title": workbook.properties.title,
                "description": workbook.properties.description,
            }
        except Exception:
            pass
    return {
        "source_pdf": props.get("title") or name,
        "page_number": page,
        "table_identifier": table_id,
        "title": sheet_name if sheet_name.lower() not in {"sheet1", "sheet"} else props.get("subject"),
        "workbook_properties": props,
    }
