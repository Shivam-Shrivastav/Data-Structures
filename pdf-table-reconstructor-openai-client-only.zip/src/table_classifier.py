import re
from .models import SourceTable

TRANSACTION_TERMS = ("trade date","transaction date","settlement date","posting date","buy","sell","purchase","redemption","deposit","withdrawal","dividend","transaction id","reference number","transaction amount","activity")
HOLDING_TERMS = ("security","ticker","isin","cusip","quantity","units","market value","cost basis","unrealized","asset class","instrument","shares held")
SUMMARY_TERMS = ("asset allocation","portfolio valuation","performance summary","account summary","summary","total portfolio","portfolio overview")

def context_for(table: SourceTable) -> dict:
    return {
        "table_id": table.table_id, "source_filename": table.source_file, "sheet_name": table.sheet_name,
        "source_pdf": table.source_pdf, "page_number": table.page_number,
        "table_identifier": table.table_identifier, "title": table.title,
        "column_headers": table.headers, "representative_rows": table.preview(6),
        "row_count": table.row_count, "column_count": table.column_count,
        "metadata": table.metadata,
    }

def heuristic_classify(table: SourceTable) -> dict:
    text = " ".join([str(x) for x in (table.title or "", *table.headers, *[v for row in table.preview(4) for v in row if v is not None])]).lower()
    headers = " ".join(str(h).lower() for h in table.headers)
    if any(t in text for t in SUMMARY_TERMS) and not any(t in headers for t in ("transaction date","trade date","security name","ticker","isin","cusip")):
        kind = "summary"
    elif any(t in headers for t in ("transaction date","trade date","settlement date","posting date","transaction id","reference number")) or (any(t in text for t in TRANSACTION_TERMS) and any(t in headers for t in ("amount","quantity","price","description","activity"))):
        kind = "transaction"
    elif any(t in headers for t in ("security name","ticker","isin","cusip","instrument name")) or (any(t in headers for t in ("market value","cost basis","quantity","units")) and any(t in headers for t in ("security","asset","instrument","name","ticker"))):
        kind = "portfolio_holdings"
    elif not any(str(h).strip() for h in table.headers) and table.rows and len(table.rows[0]) >= 3:
        first = str(table.rows[0][0] or "")
        last = table.rows[0][-1]
        date_like = bool(__import__("re").search(r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b", first))
        numeric_last = isinstance(last, (int, float)) or (isinstance(last, str) and bool(__import__("re").fullmatch(r"[-+]?\d+(?:[.,]\d+)?", last.strip())))
        if date_like and numeric_last:
            kind = "transaction"
        else:
            kind = "uncertain"
    elif any(t in text for t in SUMMARY_TERMS):
        kind = "summary"
    else:
        kind = "uncertain"
    include = kind in {"transaction","portfolio_holdings"}
    return {"table_type":kind,"include_table":include,"reasoning_summary":"Rules-based classification; inspect review sheet for uncertainty.",
            "detected_header":table.headers,"contains_detail_rows":include,"contains_subtotals":False,
            "confidence":0.70 if kind != "uncertain" else 0.35,"review_required":kind=="uncertain"}

def classify(table, provider, threshold: float) -> dict:
    if provider is None:
        return heuristic_classify(table)
    result = provider.classify_table(context_for(table))
    valid_types = {"transaction","portfolio_holdings","summary","other","uncertain"}
    if result.get("table_type") not in valid_types or not isinstance(result.get("include_table"), bool):
        raise ValueError(f"Invalid classification response for {table.table_id}")
    confidence = float(result.get("confidence", 0))
    result["confidence"] = max(0.0, min(1.0, confidence))
    if result["confidence"] < threshold or result["table_type"] == "uncertain":
        result["review_required"] = True
        result["include_table"] = False
    return result
