from .openrouter_provider import OpenRouterProvider
from .azure_openai_provider import AzureOpenAIProvider

def create_provider(config):
    if not config.enable_llm:
        return None
    if config.llm_provider == "openrouter":
        return OpenRouterProvider(config)
    if config.llm_provider == "azure_openai":
        return AzureOpenAIProvider(config)
    raise ValueError(f"Unsupported provider: {config.llm_provider}")
