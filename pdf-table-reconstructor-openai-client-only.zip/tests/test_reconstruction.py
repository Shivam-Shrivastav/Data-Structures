from pathlib import Path
from src.models import SourceTable
from src.table_normalizer import header_similarity, is_headerless
from src.row_filter import is_total_row, remove_duplicate_header_rows
from src.schema_matcher import schemas_compatible, map_columns
from src.continuation_detector import deterministic_candidate
from src.excel_writer import safe_sheet_name

def make_table(tid, page, headers, rows, pdf="demo.pdf"):
    return SourceTable(tid, f"demo_page_{page}.xlsx", "Transactions", pdf, page, "1", "Transactions",
                       headers, rows, list(range(2,2+len(rows))), {})

def test_repeated_header_removed():
    headers = ["Trade Date","Description","Amount"]
    rows = [["2026-01-01","BUY","100"],["Trade Date","Description","Amount"],["2026-01-02","SELL","-50"]]
    kept, removed = remove_duplicate_header_rows(rows, headers)
    assert len(kept) == 2
    assert len(removed) == 1

def test_headerless_continuation_same_pdf_adjacent_page():
    a = make_table("a", 1, ["Trade Date","Description","Amount"], [["2026-01-01","BUY","100"]])
    b = make_table("b", 2, ["","",""], [["2026-01-02","SELL","-50"]])
    assert is_headerless(b)
    ok, score, _ = deterministic_candidate(a, b)
    assert ok and score >= 0.85

def test_unrelated_source_not_merged_by_matching_headers():
    a = make_table("a", 1, ["Trade Date","Description","Amount"], [["2026-01-01","BUY","100"]], "one.pdf")
    b = make_table("b", 2, ["Trade Date","Description","Amount"], [["2026-01-02","SELL","-50"]], "two.pdf")
    ok, _, _ = deterministic_candidate(a, b)
    assert not ok

def test_schema_matching():
    assert schemas_compatible(["Trade Date","Description","Amount"], ["trade date","Description","Amount"])
    assert map_columns(["Trade Date","Description","Amount"], ["Trade Date","Description","Amount"]) == [0,1,2]
    assert map_columns(["Ticker","ISIN"], ["Ticker","ISIN"]) == [0,1]

def test_subtotal_detection():
    assert is_total_row(["Total Market Value", None, 1000], ["Security","Quantity","Market Value"])
    assert not is_total_row(["Interest", "Dividend interest", 5], ["Date","Description","Amount"])

def test_safe_sheet_names():
    used = set()
    a = safe_sheet_name("Transactions/Activity: Long Name That Exceeds Thirty One Characters", used)
    b = safe_sheet_name("Transactions/Activity: Long Name That Exceeds Thirty One Characters", used)
    assert len(a) <= 31 and len(b) <= 31 and a != b


def test_headerless_transaction_classification():
    from src.table_classifier import heuristic_classify
    t = make_table("b", 2, ["", "", "", ""], [["2026-01-02", "SELL", "00001234", -50.0]])
    result = heuristic_classify(t)
    assert result["table_type"] == "transaction"
