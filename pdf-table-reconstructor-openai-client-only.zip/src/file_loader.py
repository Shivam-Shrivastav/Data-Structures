from pathlib import Path

SUPPORTED = {".xlsx", ".xlsm", ".xls"}

def discover_files(input_dir: Path, output_dir: Path | None = None) -> list[Path]:
    input_dir.mkdir(parents=True, exist_ok=True)
    output_resolved = output_dir.resolve() if output_dir else None
    result = []
    for p in input_dir.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in SUPPORTED or p.name.startswith("~$"):
            continue
        if output_resolved and output_resolved in p.resolve().parents:
            continue
        result.append(p)
    return sorted(result, key=lambda p: str(p).lower())
