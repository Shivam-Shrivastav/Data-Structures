import logging
from collections import Counter

def log_summary(tables, classifications, logical_tables, review_rows):
    log = logging.getLogger(__name__)
    counts = Counter(c.get("table_type","unknown") for c in classifications.values())
    log.info("Source tables: %d; classifications: %s; logical tables: %d; review events: %d",
             len(tables), dict(counts), len(logical_tables), len(review_rows))
