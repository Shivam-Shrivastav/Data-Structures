from abc import ABC, abstractmethod

class LLMProvider(ABC):
    @abstractmethod
    def classify_table(self, table_context: dict) -> dict: ...
    @abstractmethod
    def decide_table_continuation(self, previous_table: dict, candidate_table: dict) -> dict: ...
