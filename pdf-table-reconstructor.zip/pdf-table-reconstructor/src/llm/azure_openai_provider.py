import json, time, logging
from openai import AzureOpenAI
from .openrouter_provider import CLASSIFY_SCHEMA, MERGE_SCHEMA
from .base import LLMProvider

log = logging.getLogger(__name__)

class AzureOpenAIProvider(LLMProvider):
    def __init__(self, config):
        self.config = config
        self.client = AzureOpenAI(
            api_key=config.azure_openai_api_key,
            azure_endpoint=config.azure_openai_endpoint,
            api_version=config.azure_openai_api_version,
            timeout=config.llm_timeout_seconds,
            max_retries=0,
        )

    def _json_call(self, system, payload, schema, name):
        last = None
        for attempt in range(self.config.max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=self.config.azure_openai_deployment,
                    messages=[{"role":"system","content":system},
                              {"role":"user","content":json.dumps(payload, ensure_ascii=False, default=str)}],
                    response_format={"type":"json_schema","json_schema":{"name":name,"strict":True,"schema":schema}},
                )
                result = json.loads(response.choices[0].message.content)
                if not isinstance(result, dict):
                    raise ValueError("LLM response was not a JSON object")
                return result
            except Exception as exc:
                last = exc
                log.warning("Azure LLM request failed (attempt %s/%s): %s", attempt+1, self.config.max_retries, type(exc).__name__)
                if attempt + 1 < self.config.max_retries:
                    time.sleep(min(2 ** attempt, 4))
        raise RuntimeError(f"Azure LLM request failed after retries: {type(last).__name__}") from last

    def classify_table(self, table_context):
        return self._json_call(
            "Classify financial extracted tables by actual row-level meaning. Include individual transactions and individual portfolio holdings only. Exclude summaries and unrelated tables. Be conservative and flag uncertainty.",
            table_context, CLASSIFY_SCHEMA, "table_classification")

    def decide_table_continuation(self, previous_table, candidate_table):
        return self._json_call(
            "Decide whether a candidate table continues the prior logical table. Matching headers alone is insufficient. Use source, page order, schema, title, rows and context. Do not change source values. Use uncertain when evidence is insufficient.",
            {"previous_table":previous_table,"candidate_table":candidate_table}, MERGE_SCHEMA, "table_continuation")
