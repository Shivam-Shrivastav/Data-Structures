from .table_normalizer import header_similarity, is_headerless, norm_text
from .schema_matcher import schemas_compatible, map_columns

def deterministic_candidate(previous, candidate) -> tuple[bool, float, str]:
    if len(previous.headers) != len(candidate.headers):
        return False, 0.0, "Column count differs"
    same_source = bool(previous.source_pdf and candidate.source_pdf and previous.source_pdf == candidate.source_pdf)
    adjacent = (previous.page_number is not None and candidate.page_number is not None
                and candidate.page_number == previous.page_number + 1)
    # If both page numbers exist, require increasing adjacent order; avoid arbitrary file order.
    if previous.page_number is not None and candidate.page_number is not None and not adjacent:
        return False, 0.0, "Pages are not consecutive"
    if previous.source_pdf and candidate.source_pdf and previous.source_pdf != candidate.source_pdf:
        return False, 0.0, "Source PDF differs"
    if is_headerless(candidate):
        if same_source and adjacent:
            return True, 0.88, "Headerless table from same PDF on immediately following page"
        return False, 0.0, "Headerless candidate lacks reliable source/page evidence"
    if not schemas_compatible(previous.headers, candidate.headers):
        return False, 0.0, "Schema mismatch"
    sim = header_similarity(previous.headers, candidate.headers)
    if same_source and adjacent and sim >= 0.75:
        return True, min(0.97, 0.82 + sim * 0.15), "Same PDF, adjacent page and compatible schema"
    # If metadata is absent, do not auto-merge just on matching headers.
    return False, 0.0, "Insufficient source/page evidence"

def context_for_merge(previous, candidate):
    return {
        "table_id": previous.table_id, "table_type": previous.table_type, "title": previous.title,
        "source_pdf": previous.sources[-1] if previous.sources else None,
        "headers": previous.headers, "representative_rows": previous.rows[-5:],
    }, {
        "table_id": candidate.table_id, "title": candidate.title, "source_pdf": candidate.source_pdf,
        "page_number": candidate.page_number, "headers": candidate.headers,
        "representative_rows": candidate.preview(5), "row_count": candidate.row_count,
    }

def decide_continuation(previous, candidate, provider, threshold):
    ok, score, reason = deterministic_candidate(previous, candidate)
    if ok:
        return {"decision":"merge","confidence":score,"reasoning_summary":reason,"review_required":False,
                "header_present":not is_headerless(candidate),"header_matches_existing":not is_headerless(candidate),
                "header_mapping":list(range(len(previous.headers))),"rows_to_remove":[]}
    if provider is None:
        return {"decision":"uncertain","confidence":score,"reasoning_summary":reason,"review_required":True,
                "header_present":not is_headerless(candidate),"header_matches_existing":False,
                "header_mapping":[],"rows_to_remove":[]}
    prev_ctx, cand_ctx = context_for_merge(previous, candidate)
    result = provider.decide_table_continuation(prev_ctx, cand_ctx)
    decision = result.get("decision", "uncertain")
    confidence = float(result.get("confidence", 0))
    if decision != "merge" or confidence < threshold:
        result["decision"] = "uncertain" if decision == "merge" else decision
        result["review_required"] = True
    return result
