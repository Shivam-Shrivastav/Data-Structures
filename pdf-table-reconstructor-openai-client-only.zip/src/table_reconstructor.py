from collections import defaultdict
from .models import LogicalTable
from .continuation_detector import decide_continuation
from .row_filter import is_total_row, remove_duplicate_header_rows
from .table_normalizer import is_headerless
from .schema_matcher import map_columns

def _ordered(tables):
    # Use explicit metadata where available. Unknown page order remains flagged rather than inferred from filename.
    return sorted(tables, key=lambda t: (
        t.source_pdf or "~unknown",
        t.page_number if t.page_number is not None else 10**9,
        t.table_identifier or "~unknown",
        t.source_file.lower(), t.sheet_name.lower()
    ))

def reconstruct(classified_tables, classifications, provider, config):
    logical = []
    review = []
    source_by_id = {t.table_id:t for t in classified_tables}
    included = []
    for table in classified_tables:
        c = classifications[table.table_id]
        if not c.get("include_table", False):
            review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"page_number":table.page_number,
                           "table_id":table.table_id,"action":"excluded","confidence":c.get("confidence"),
                           "reason":c.get("reasoning_summary"),"review_required":c.get("review_required",False)})
            continue
        if c.get("confidence",0) < config.classification_threshold:
            review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"page_number":table.page_number,
                           "table_id":table.table_id,"action":"held_for_review","confidence":c.get("confidence"),
                           "reason":"Classification confidence below threshold","review_required":True})
            continue
        included.append((table,c))

    # Each new table is a possible continuation only of recent logical tables from the same source.
    for table, classification in _ordered_pairs(included):
        headers = list(table.headers)
        if is_headerless(table):
            candidates = [lt for lt in logical if lt.sources and lt.sources[-1].split("::")[0] == table.source_pdf]
        else:
            candidates = [lt for lt in logical if lt.table_type == classification["table_type"]]
        selected = None
        selected_decision = None
        for lt in reversed(candidates):
            prev_src = source_by_id.get(lt.sources[-1].split("::",1)[-1])
            # provenance IDs are encoded as filename::sheet; recover by exact source table id if possible
            if prev_src is None:
                prev_src = next((x for x in classified_tables if x.table_id == lt.sources[-1]), None)
            if prev_src is None:
                continue
            decision = decide_continuation(lt, table, provider, config.merge_threshold)
            if decision.get("decision") == "merge" and not decision.get("review_required", False):
                selected, selected_decision = lt, decision
                break
            if decision.get("review_required"):
                review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"page_number":table.page_number,
                               "table_id":table.table_id,"action":"continuation_review","target_table_id":lt.table_id,
                               "confidence":decision.get("confidence"),"reason":decision.get("reasoning_summary"),
                               "review_required":True})
        if selected is None:
            lt = LogicalTable(table_id=f"logical_{len(logical)+1:03d}", table_type=classification["table_type"],
                              title=table.title or ("Transactions" if classification["table_type"]=="transaction" else "Portfolio_Holdings"),
                              headers=headers, confidence=classification.get("confidence",0.5),
                              needs_review=classification.get("review_required",False), source_pdf=table.source_pdf, page_number=table.page_number)
            clean_rows = table.rows
            clean_rows, removed_headers = remove_duplicate_header_rows(clean_rows, headers)
            for item in removed_headers:
                review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"table_id":table.table_id,
                               "action":"row_removed","confidence":1.0,"reason":item["reason"],"row_index":item["row_index"],"review_required":False})
            for i,row in enumerate(clean_rows):
                if is_total_row(row, headers):
                    review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"table_id":table.table_id,
                                   "action":"row_removed","confidence":0.9,"reason":"Subtotal/total row","row_values":str(row),
                                   "review_required":False})
                else:
                    lt.rows.append(row)
            lt.sources.append(table.table_id)
            logical.append(lt)
        else:
            if is_headerless(table):
                mapping = list(range(len(selected.headers)))
            else:
                mapping = map_columns(table.headers, selected.headers)
                if mapping is None:
                    review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"table_id":table.table_id,
                                   "action":"merge_blocked","target_table_id":selected.table_id,"confidence":0.0,
                                   "reason":"Could not validate one-to-one column mapping","review_required":True})
                    continue
            rows = table.rows
            # Remove duplicate header rows even if the table had a header row represented as data.
            rows, removed_headers = remove_duplicate_header_rows(rows, selected.headers)
            for item in removed_headers:
                review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"table_id":table.table_id,
                               "action":"row_removed","confidence":1.0,"reason":item["reason"],"row_index":item["row_index"],"review_required":False})
            for row in rows:
                if is_total_row(row, selected.headers):
                    review.append({"source_file":table.source_file,"sheet_name":table.sheet_name,"table_id":table.table_id,
                                   "action":"row_removed","confidence":0.9,"reason":"Subtotal/total row","row_values":str(row),"review_required":False})
                    continue
                newrow = [None] * len(selected.headers)
                for ci, oi in enumerate(mapping):
                    if ci < len(row) and oi < len(newrow):
                        newrow[oi] = row[ci]
                selected.rows.append(newrow)
            selected.sources.append(table.table_id)
            selected.source_pdf = table.source_pdf
            selected.page_number = table.page_number
            selected.confidence = min(selected.confidence, selected_decision.get("confidence",1.0))
    return logical, review

def _ordered_pairs(included):
    # Keep all tables; deterministic ordering is based on explicit page metadata and then filename.
    return sorted(included, key=lambda pair: (
        pair[0].source_pdf or "~unknown",
        pair[0].page_number if pair[0].page_number is not None else 10**9,
        pair[0].table_identifier or "~unknown",
        pair[0].source_file.lower(), pair[0].sheet_name.lower()
    ))
