from dataclasses import dataclass
from pathlib import Path
import os
from dotenv import load_dotenv

@dataclass
class Config:
    llm_provider: str = "openrouter"
    openrouter_api_key: str = ""
    openrouter_model: str = "openai/gpt-4o-mini"
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    azure_openai_api_key: str = ""
    azure_openai_endpoint: str = ""
    azure_openai_api_version: str = ""  # Not required by Azure OpenAI v1 API
    azure_openai_deployment: str = ""
    input_dir: Path = Path("./input")
    output_dir: Path = Path("./output")
    output_filename: str = "reconstructed_tables.xlsx"
    classification_threshold: float = 0.80
    merge_threshold: float = 0.85
    enable_review_sheet: bool = True
    max_retries: int = 3
    batch_size: int = 10
    llm_timeout_seconds: int = 45
    enable_llm: bool = True

    @classmethod
    def from_env(cls) -> "Config":
        load_dotenv()
        cfg = cls(
            llm_provider=os.getenv("LLM_PROVIDER", "openrouter").strip().lower(),
            openrouter_api_key=os.getenv("OPENROUTER_API_KEY", ""),
            openrouter_model=os.getenv("OPENROUTER_MODEL", "openai/gpt-4o-mini"),
            openrouter_base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
            azure_openai_api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
            azure_openai_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
            azure_openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION", ""),
            azure_openai_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", ""),
            input_dir=Path(os.getenv("INPUT_DIR", "./input")),
            output_dir=Path(os.getenv("OUTPUT_DIR", "./output")),
            output_filename=os.getenv("OUTPUT_FILENAME", "reconstructed_tables.xlsx"),
            classification_threshold=float(os.getenv("CLASSIFICATION_CONFIDENCE_THRESHOLD", "0.80")),
            merge_threshold=float(os.getenv("MERGE_CONFIDENCE_THRESHOLD", "0.85")),
            enable_review_sheet=os.getenv("ENABLE_REVIEW_SHEET", "true").lower() == "true",
            max_retries=max(1, int(os.getenv("MAX_RETRIES", "3"))),
            batch_size=max(1, int(os.getenv("BATCH_SIZE", "10"))),
            llm_timeout_seconds=max(5, int(os.getenv("LLM_TIMEOUT_SECONDS", "45"))),
            enable_llm=os.getenv("ENABLE_LLM", "true").lower() == "true",
        )
        cfg.validate()
        return cfg

    def validate(self) -> None:
        if self.llm_provider not in {"openrouter", "azure_openai"}:
            raise ValueError("LLM_PROVIDER must be 'openrouter' or 'azure_openai'.")
        if not 0 <= self.classification_threshold <= 1 or not 0 <= self.merge_threshold <= 1:
            raise ValueError("Confidence thresholds must be between 0 and 1.")
        if self.enable_llm:
            if self.llm_provider == "openrouter" and not self.openrouter_api_key:
                raise ValueError("OPENROUTER_API_KEY is required when LLM_PROVIDER=openrouter and ENABLE_LLM=true.")
            if self.llm_provider == "azure_openai":
                missing = [k for k, v in {
                    "AZURE_OPENAI_API_KEY": self.azure_openai_api_key,
                    "AZURE_OPENAI_ENDPOINT": self.azure_openai_endpoint,
                    "AZURE_OPENAI_DEPLOYMENT": self.azure_openai_deployment,
                }.items() if not v]
                if missing:
                    raise ValueError("Missing Azure settings: " + ", ".join(missing))
