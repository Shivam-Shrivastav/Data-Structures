import logging
from pathlib import Path
from config import Config
from src.file_loader import discover_files
from src.excel_reader import read_workbook
from src.llm.provider_factory import create_provider
from src.table_classifier import classify
from src.table_reconstructor import reconstruct
from src.excel_writer import write_output
from src.review_report import log_summary

def setup_logging():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def main():
    setup_logging()
    log = logging.getLogger("main")
    config = Config.from_env()
    config.output_dir.mkdir(parents=True, exist_ok=True)
    files = discover_files(config.input_dir, config.output_dir)
    if not files:
        raise SystemExit(f"No Excel input files found in {config.input_dir.resolve()}. Add .xlsx/.xls files and retry.")
    tables = []
    for path in files:
        try:
            found = read_workbook(path)
            tables.extend(found)
            log.info("Read %d candidate table(s) from %s", len(found), path.name)
        except Exception as exc:
            log.exception("Failed to read workbook %s: %s", path.name, type(exc).__name__)
    if not tables:
        raise SystemExit("No non-empty worksheets/tables could be read.")
    provider = create_provider(config)
    classifications = {}
    for i, table in enumerate(tables, start=1):
        try:
            classifications[table.table_id] = classify(table, provider, config.classification_threshold)
        except Exception as exc:
            classifications[table.table_id] = {
                "table_type":"uncertain","include_table":False,"reasoning_summary":f"Classification failed: {type(exc).__name__}",
                "detected_header":table.headers,"contains_detail_rows":False,"contains_subtotals":False,
                "confidence":0.0,"review_required":True,
            }
            log.warning("Could not classify %s; held for review", table.table_id)
        log.info("Classified table %d/%d", i, len(tables))
    logical, review = reconstruct(tables, classifications, provider, config)
    output_path = config.output_dir / config.output_filename
    write_output(logical, review, output_path, config.enable_review_sheet)
    log_summary(tables, classifications, logical, review)
    log.info("Wrote %s", output_path.resolve())

if __name__ == "__main__":
    main()
