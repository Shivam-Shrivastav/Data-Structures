from dataclasses import dataclass, field
from typing import Any

@dataclass
class SourceTable:
    table_id: str
    source_file: str
    sheet_name: str
    source_pdf: str | None
    page_number: int | None
    table_identifier: str | None
    title: str | None
    headers: list[str]
    rows: list[list[Any]]
    original_row_indices: list[int] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def column_count(self) -> int:
        return len(self.headers)

    @property
    def row_count(self) -> int:
        return len(self.rows)

    def preview(self, limit: int = 5) -> list[list[Any]]:
        return self.rows[:limit]

@dataclass
class LogicalTable:
    table_id: str
    table_type: str
    title: str
    headers: list[str]
    rows: list[list[Any]] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    confidence: float = 1.0
    needs_review: bool = False
    source_pdf: str | None = None
    page_number: int | None = None
